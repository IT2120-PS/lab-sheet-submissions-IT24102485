setwd("C:/Users/Pasindu/Desktop/PS_Lab05_IT24102485")

delivery_times <- read.table("Exercise - Lab 05.txt", header = TRUE)
head(delivery_times)

names(delivery_times)[1] <- "Delivery_Times"
breaks_seq <- seq(20, 70, by = (70 - 20)/9)

hist(delivery_times$Delivery_Times,
     breaks = breaks_seq,
     right = FALSE,
     col = "lightblue",
     main = "Histogram of Delivery Times",
     xlab = "Delivery Times",
     ylab = "Frequency")

hist_data <- hist(delivery_times$Delivery_Times,
                  breaks = breaks_seq,
                  plot = FALSE,
                  right = FALSE)

cum_freq <- cumsum(hist_data$counts)
plot (breaks_seq [-1], cum_freq, type = "o", col = "blue",  
      
      main = "Cumulative Frequency Polygon (Ogive)",  
      
      xlab= "Delivery Times", 
      
      ylab = "Cumulative Frequency") 


